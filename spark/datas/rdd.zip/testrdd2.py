from pyspark import SparkContext

# 初始化SparkContext
sc = SparkContext('local', 'remdup')

# 加载两个文件A和B
lines1 = sc.textFile("a.txt")
lines2 = sc.textFile("b.txt")

# 合并两个文件的内容
lines = lines1.union(lines2)

# 去重操作
distinct_lines = lines.distinct()

# 排序操作
res = distinct_lines.sortBy(lambda x: x)

# 将结果写入result文件中，repartition(1)的作用是让结果合并到一个文件中，不加的话会结果写入到两个文件
res.repartition(1).saveAsTextFile("remdupfile")
