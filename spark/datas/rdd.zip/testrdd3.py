from pyspark import SparkContext

# 初始化SparkContext
sc = SparkContext('local', ' avgscore')

# 加载三个文件Algorithm.txt、Database.txt和Python.txt
lines1 = sc.textFile("Algorithm.txt")
lines2 = sc.textFile("Database.txt")
lines3 = sc.textFile("Python.txt")

# 合并三个文件的内容
lines = lines1.union(lines2).union(lines3)

# 为每行数据新增一列1，方便后续统计每个学生选修的课程数目。data的数据格式为('小明', (92, 1))
data = lines.map(lambda x: x.split(" ")).map(lambda x: (x[0], (int(x[1]), 1)))

# 根据key也就是学生姓名合计每门课程的成绩，以及选修的课程数目。res的数据格式为('小明', (269, 3))
res = data.reduceByKey(lambda x, y: (x[0] + y[0], x[1] + y[1]))

# 利用总成绩除以选修的课程数来计算每个学生的每门课程的平均分，并利用round(x,2)保留两位小数
result = res.map(lambda x: (x[0], round(x[1][0] / x[1][1], 2)))

# 将结果写入result文件中，repartition(1)的作用是让结果合并到一个文件中，不加的话会结果写入到三个文件
result.repartition(1).saveAsTextFile("avgscore")
