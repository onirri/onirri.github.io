from pyspark import SparkContext

sc = SparkContext()
lines = sc.textFile('data01.txt')

#该系总共有多少学生
res = lines.map(lambda x: x.split(',')).map(lambda x: x[0])
distinct_res = res.distinct()
print(distinct_res.count())

#该系共开设了多少门课程
res = lines.map(lambda x: x.split(',')).map(lambda x: x[1])
distinct_res = res.distinct()
print(distinct_res.count())

#tdu同学的总成绩平均分是多少
res = lines.map(lambda x: x.split(",")).filter(lambda x: x[0] == "tdu")
res.foreach(print)
score = res.map(lambda x: int(x[2]))
num = res.count()
sum_score = score.reduce(lambda x, y: x + y)
avg = sum_score / num
print(avg)

#求每名同学的选修的课程门数
res = lines.map(lambda x: x.split(",")).map(lambda x: (x[0], 1))
each_res = res.reduceByKey(lambda x, y: x + y)
each_res.foreach(print)

#该系Spark课程共有多少人选修
res = lines.map(lambda x: x.split(",")).filter(lambda x: x[1] == "Spark")
print(res.count())

#各门课程的平均分是多少
res = lines.map(lambda x: x.split(",")).map(lambda x: (x[1], (int(x[2]), 1)))
temp = res.reduceByKey(lambda x, y: (x[0] + y[0], x[1] + y[1]))
avg = temp.map(lambda x: (x[0], round(x[1][0] / x[1][1], 2)))
avg.foreach(print)

#使用累加器计算共有多少人选了Java这门课
res = lines.map(lambda x: x.split(",")).filter(lambda x: x[1] == "Java")
accum = sc.accumulator(0)
res.foreach(lambda x: accum.add(1))
print(accum.value)
