import random

ft = open("data01.txt", "w+")
course = ['DataBase', 'Algorithm', 'DataStructure', 'Spark', 'Python', 'Hadoop', 'Network', 'Java']
strdata = ''
for i in range(265):
    len = random.randint(3, 6)
    name = random.sample('zyxwvutsrqponmlkjihgfedcba', len)
    strname = ''.join(name)
    for j in range(random.randint(3, 8)):
        strdata += strname + ',' + course[j] + ',' + str(random.randint(50, 100)) + '\n'

ft.write(strdata)

